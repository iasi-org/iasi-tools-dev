// Command iasi-dev is the IASI development command-line entry point.
package main

import (
	"fmt"
	"os"
)

func main() {
	if len(os.Args) == 1 {
		printHelp()
		return
	}

	runCommand(os.Args[1], os.Args[2:])
}

func runCommand(command string, args []string) {
	switch command {
	case "help":
		printHelp()
	case "build":
		runBuild(args)
	case "publish":
		runPublish(args)
	case "deploy":
		runDeploy(args)
	default:
		fmt.Fprintf(os.Stderr, "Unknown command %q\n", command)
		os.Exit(2)
	}
}

func runBuild(args []string) {
}

func runPublish(args []string) {
}

func runDeploy(args []string) {
}

func printHelp() {
	fmt.Print(`IASI Dev

Usage:
  iasi-dev <command>

Commands:
  help       Show help
  build      Build
  publish    Publish
  deploy     Deploy
`)
}
