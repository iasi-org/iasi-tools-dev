// Command iasi-dev is the IASI development command-line entry point.
package main

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"iasi-dev/internal/RC"
	"iasi-dev/internal/cli"
)

type Arguments struct {
	Silent   bool
	Verbose  bool
	Force    bool
	Tolerant bool
	Message  string
	Format   string
	LogFile  string
	Params   map[string]string
}

func main() {
	if len(os.Args) == 1 {
		printHelp()
		os.Exit(RC.OK)
	}

	command := os.Args[1]
	arguments, directoryArgs := parseArguments(command, os.Args[2:])

	logFile, err := createLogFile(command)
	if err != nil {
		fmt.Fprintf(os.Stderr, "No se pudo crear el log: %v\n", err)
		os.Exit(RC.Error)
	}

	arguments.LogFile = logFile
	cli.ConfigureOutput(cli.OutputOptions{Silent: arguments.Silent, Verbose: arguments.Verbose, LogFile: arguments.LogFile})
	directories := selectDirectories(directoryArgs)
	directories = selectIASIDirectories(directories)

	runCommand(command, arguments, directories)
	os.Exit(RC.OK)
}

// createLogFile creates the log for the complete iasi-dev execution.
func createLogFile(command string) (string, error) {
	cwd, err := os.Getwd()
	if err != nil {
		return "", err
	}

	logDir := filepath.Join(cwd, "logs")
	if err := os.MkdirAll(logDir, 0755); err != nil {
		return "", err
	}

	logFile := filepath.Join(logDir, fmt.Sprintf("iasi-%s-%s.log", command, time.Now().Format("20060102150405")))
	file, err := os.Create(logFile)
	if err != nil {
		return "", err
	}

	if err := file.Close(); err != nil {
		return "", err
	}

	return logFile, nil
}

// parseArguments converts command-line options into the common arguments structure.
func parseArguments(command string, args []string) (Arguments, []string) {
	arguments := Arguments{Message: "iasi-dev " + command, Params: map[string]string{}}
	directories := []string{}

	for len(args) > 0 {
		argument := args[0]

		switch argument {
		case "-s":
			arguments.Silent = true
			args = args[1:]
		case "-v":
			arguments.Verbose = true
			args = args[1:]
		case "-f":
			arguments.Force = true
			args = args[1:]
		case "-t":
			arguments.Tolerant = true
			args = args[1:]
		default:
			if strings.HasPrefix(argument, "--") {
				key := strings.TrimPrefix(argument, "--")
				value := ""

				if len(args) > 1 {
					value = args[1]
					args = args[2:]
				} else {
					args = args[1:]
				}

				if key == "message" {
					arguments.Message = value
					continue
				}

				if key == "format" {
					arguments.Format = value
					continue
				}

				arguments.Params[key] = value
				continue
			}

			directories = append(directories, argument)
			args = args[1:]
		}
	}

	return arguments, directories
}

// selectDirectories resolves the directories that will be processed.
// Without explicit directories, it returns the direct children of the current directory.
func selectDirectories(candidates []string) []string {
	if len(candidates) == 0 {
		return firstLevelDirectories(".")
	}

	directories := []string{}

	for _, candidate := range candidates {
		if filepath.Clean(candidate) == "." {
			directories = append(directories, firstLevelDirectories(candidate)...)
			continue
		}

		directory, err := filepath.Abs(candidate)
		if err != nil {
			cli.Warning("Se ignora %q: no se puede resolver la ruta.", candidate)
			continue
		}

		if isIgnoredDirectory(directory) {
			continue
		}

		info, err := os.Stat(directory)
		if err != nil || !info.IsDir() {
			cli.Warning("Se ignora %q: no existe o no es un directorio.", candidate)
			continue
		}

		directories = append(directories, filepath.Clean(directory))
	}

	return directories
}

// firstLevelDirectories returns only the direct child directories of root.
func firstLevelDirectories(root string) []string {
	root, err := filepath.Abs(root)
	if err != nil {
		cli.Warning("Se ignora %q: no se puede resolver la ruta.", root)
		return nil
	}

	if isIgnoredDirectory(root) {
		return nil
	}

	entries, err := os.ReadDir(root)
	if err != nil {
		cli.Warning("Se ignora %q: no existe o no se puede leer.", root)
		return nil
	}

	directories := []string{}

	for _, entry := range entries {
		if !entry.IsDir() || entry.Name() == "tests" {
			continue
		}

		directories = append(directories, filepath.Join(root, entry.Name()))
	}

	return directories
}

// isIgnoredDirectory reports whether a path is inside a tests directory.
func isIgnoredDirectory(path string) bool {
	path = filepath.Clean(path)

	for {
		if filepath.Base(path) == "tests" {
			return true
		}

		parent := filepath.Dir(path)
		if parent == path {
			return false
		}

		path = parent
	}
}

// selectIASIDirectories keeps only directories marked as IASI repositories.
func selectIASIDirectories(directories []string) []string {
	selected := []string{}

	for _, directory := range directories {
		if !hasIASIMarker(directory) {
			continue
		}

		selected = append(selected, directory)
	}

	return selected
}

// hasIASIMarker reports whether a directory contains an IASI marker in its root.
func hasIASIMarker(directory string) bool {
	return iasiMarkerPath(directory) != ""
}

// fileExists reports whether path exists and is a regular filesystem entry rather than a directory.
func fileExists(path string) bool {
	info, err := os.Stat(path)
	return err == nil && !info.IsDir()
}

// isGitRepository reports whether the directory is a Git repository.
func isGitRepository(directory string) bool {
	_, err := os.Stat(filepath.Join(directory, ".git"))
	return err == nil
}

// runCommand dispatches the selected command.
func runCommand(command string, arguments Arguments, directories []string) {
	switch command {
	case "help": printHelp()
	case "build": runBuild(arguments, directories)
	case "publish": runPublish(arguments, directories)
	case "deploy": runDeploy(arguments, directories)
	default:
		cli.Error("Comando desconocido: %q", command)
		os.Exit(RC.InvalidArguments)
	}
}

// findArtifacts returns the IASI artifacts declared below a repository.
// Directories named tests are never traversed.
func findArtifacts(repository string) []string {
	artifacts := []string{}

	filepath.WalkDir(repository, func(path string, entry os.DirEntry, err error) error {
		if err != nil || !entry.IsDir() {
			return nil
		}

		if entry.Name() == "tests" {
			return filepath.SkipDir
		}

		if path == repository {
			return nil
		}

		if hasIASIMarker(path) {
			artifacts = append(artifacts, path)
		}

		return nil
	})

	return artifacts
}

// runBuild builds every artifact found in the selected repositories.
func runBuild(arguments Arguments, repositories []string) {
	for _, repository := range repositories {
		if !isGitRepository(repository) {
			continue
		}

		cli.Info("Construyendo %s", filepath.Base(repository))
		artifacts := findArtifacts(repository)

		for _, artifact := range artifacts {
			err := buildArtifact(artifact, arguments)
			if err == nil {
				continue
			}
			if arguments.Tolerant {
				cli.Warning("%v", err)
				continue
			}

			cli.Error("%v", err)
			cli.Error("Consulta el log: %s", arguments.LogFile)
			os.Exit(RC.Build)
		}
	}
}

// buildArtifact builds one artifact according to its declared IASI type.
func buildArtifact(artifact string, arguments Arguments) error {
	iasi, ok := readIASI(artifact)
	if !ok {
		return nil
	}

	switch iasi.Type {
	case "r-package": return buildRPackage(artifact, arguments, iasi)
	case "quarto": return buildQuarto(artifact, arguments, iasi)
	default: cli.Warning("Se ignora %s: type ausente o no soportado: %q.", artifact, iasi.Type)
	}

	return nil
}

// buildRPackage builds an R package artifact.
func buildRPackage(artifact string, arguments Arguments, iasi IASI) error {
	return nil
}

// buildQuarto builds a Quarto artifact with iasi.quarto.
func buildQuarto(artifact string, arguments Arguments, iasi IASI) error {
	expression := quartoBuildExpression(arguments)
	command := exec.Command("Rscript", "-e", expression)
	command.Dir = artifact

	log, err := os.OpenFile(arguments.LogFile, os.O_APPEND|os.O_WRONLY, 0644)
	if err != nil {
		return fmt.Errorf("no se puede abrir el log %s: %w", arguments.LogFile, err)
	}
	defer log.Close()

	command.Stdout = log
	command.Stderr = log

	if err := command.Run(); err != nil {
		return fmt.Errorf("no se pudo construir %s: %w", artifact, err)
	}

	cli.Success("%s: build completado.", filepath.Base(artifact))
	return nil
}

// quartoBuildExpression builds the R expression for iasi.quarto::build().
func quartoBuildExpression(arguments Arguments) string {
	parameters := []string{}

	if arguments.Format != "" {
		parameters = append(parameters, "format = "+strconv.Quote(arguments.Format))
	}

	if arguments.Force {
		parameters = append(parameters, "force = TRUE")
	}

	return "iasi.quarto::build(" + strings.Join(parameters, ", ") + ")"
}

// runPublish publishes the selected repositories.
func runPublish(arguments Arguments, directories []string) {
}

// runDeploy deploys the selected repositories.
func runDeploy(arguments Arguments, directories []string) {
}

// printHelp shows the command-line help.
func printHelp() {
	cli.Direct(`IASI Dev

Usage:
  iasi-dev <command> [-s] [-v] [-f] [-t] [--format value] [--key value] [directory...]

Commands:
  help       Show help
  build      Build
  publish    Publish
  deploy     Deploy
`)
}
