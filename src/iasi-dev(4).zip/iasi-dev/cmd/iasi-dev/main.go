// Command iasi-dev is the IASI development command-line entry point.
package main

import (
	"os"
	"path/filepath"
	"strings"

	"iasi-dev/internal/cli"
)

type Arguments struct {
	Silent  bool
	Verbose bool
	Message string
	Params  map[string]string
}

func main() {
	if len(os.Args) == 1 {
		printHelp()
		return
	}

	command := os.Args[1]
	arguments, directoryArgs := parseArguments(command, os.Args[2:])
	cli.ConfigureOutput(cli.OutputOptions{Silent: arguments.Silent, Verbose: arguments.Verbose})
	directories := selectDirectories(directoryArgs)
	directories = selectIASIDirectories(directories)

	runCommand(command, arguments, directories)
}

// parseArguments converts command-line options into the common arguments structure.
func parseArguments(command string, args []string) (Arguments, []string) {
	arguments := Arguments{Message: "iasi-dev " + command, Params: map[string]string{}}
	directories := []string{}

	for len(args) > 0 {
		argument := args[0]

		switch argument {
		case "-s":
			arguments.Silent = true
			args = args[1:]
		case "-v":
			arguments.Verbose = true
			args = args[1:]
		default:
			if strings.HasPrefix(argument, "--") {
				key := strings.TrimPrefix(argument, "--")
				value := ""

				if len(args) > 1 {
					value = args[1]
					args = args[2:]
				} else {
					args = args[1:]
				}

				if key == "message" {
					arguments.Message = value
					continue
				}

				arguments.Params[key] = value
				continue
			}

			directories = append(directories, argument)
			args = args[1:]
		}
	}

	return arguments, directories
}

// selectDirectories resolves the directories that will be processed.
// Without explicit directories, it returns the direct children of the current directory.
func selectDirectories(candidates []string) []string {
	if len(candidates) == 0 {
		return firstLevelDirectories(".")
	}

	directories := []string{}

	for _, candidate := range candidates {
		if filepath.Clean(candidate) == "." {
			directories = append(directories, firstLevelDirectories(candidate)...)
			continue
		}

		directory, err := filepath.Abs(candidate)
		if err != nil {
			cli.Warning("Se ignora %q: no se puede resolver la ruta.", candidate)
			continue
		}

		if isIgnoredDirectory(directory) {
			continue
		}

		info, err := os.Stat(directory)
		if err != nil || !info.IsDir() {
			cli.Warning("Se ignora %q: no existe o no es un directorio.", candidate)
			continue
		}

		directories = append(directories, filepath.Clean(directory))
	}

	return directories
}

// firstLevelDirectories returns only the direct child directories of root.
func firstLevelDirectories(root string) []string {
	root, err := filepath.Abs(root)
	if err != nil {
		cli.Warning("Se ignora %q: no se puede resolver la ruta.", root)
		return nil
	}

	if isIgnoredDirectory(root) {
		return nil
	}

	entries, err := os.ReadDir(root)
	if err != nil {
		cli.Warning("Se ignora %q: no existe o no se puede leer.", root)
		return nil
	}

	directories := []string{}

	for _, entry := range entries {
		if !entry.IsDir() || entry.Name() == "tests" {
			continue
		}

		directories = append(directories, filepath.Join(root, entry.Name()))
	}

	return directories
}

// isIgnoredDirectory reports whether a path is inside a tests directory.
func isIgnoredDirectory(path string) bool {
	path = filepath.Clean(path)

	for {
		if filepath.Base(path) == "tests" {
			return true
		}

		parent := filepath.Dir(path)
		if parent == path {
			return false
		}

		path = parent
	}
}

// selectIASIDirectories keeps only directories marked as IASI repositories.
func selectIASIDirectories(directories []string) []string {
	selected := []string{}

	for _, directory := range directories {
		if !hasIASIMarker(directory) {
			continue
		}

		selected = append(selected, directory)
	}

	return selected
}

// hasIASIMarker reports whether a directory contains an IASI marker in its root.
func hasIASIMarker(directory string) bool {
	return iasiMarkerPath(directory) != ""
}

// fileExists reports whether path exists and is a regular filesystem entry rather than a directory.
func fileExists(path string) bool {
	info, err := os.Stat(path)
	return err == nil && !info.IsDir()
}

// isGitRepository reports whether the directory is a Git repository.
func isGitRepository(directory string) bool {
	_, err := os.Stat(filepath.Join(directory, ".git"))
	return err == nil
}

// runCommand dispatches the selected command.
func runCommand(command string, arguments Arguments, directories []string) {
	switch command {
	case "help":
		printHelp()
	case "build":
		runBuild(arguments, directories)
	case "publish":
		runPublish(arguments, directories)
	case "deploy":
		runDeploy(arguments, directories)
	default:
		cli.Error("Unknown command %q", command)
		os.Exit(2)
	}
}

// findArtifacts returns the IASI artifacts declared below a repository.
// Directories named tests are never traversed.
func findArtifacts(repository string) []string {
	artifacts := []string{}

	filepath.WalkDir(repository, func(path string, entry os.DirEntry, err error) error {
		if err != nil || !entry.IsDir() {
			return nil
		}

		if entry.Name() == "tests" {
			return filepath.SkipDir
		}

		if path == repository {
			return nil
		}

		if hasIASIMarker(path) {
			artifacts = append(artifacts, path)
		}

		return nil
	})

	return artifacts
}

// runBuild builds every artifact found in the selected repositories.
func runBuild(arguments Arguments, repositories []string) {
	for _, repository := range repositories {
		if !isGitRepository(repository) {
			continue
		}

		cli.Info("Construyendo %s", filepath.Base(repository))
		artifacts := findArtifacts(repository)

		for _, artifact := range artifacts {
			buildArtifact(artifact, arguments)
		}
	}
}

// buildArtifact builds one artifact according to its declared IASI type.
func buildArtifact(artifact string, arguments Arguments) {
	iasi, ok := readIASI(artifact)
	if !ok {
		return
	}

	switch iasi.Type {
	case "r-package": buildRPackage(artifact, arguments, iasi)
	case "quarto": buildQuarto(artifact, arguments, iasi)
	default: cli.Warning("Se ignora %s: type ausente o no soportado: %q.", artifact, iasi.Type)
	}
}

// buildRPackage builds an R package artifact.
func buildRPackage(artifact string, arguments Arguments, iasi IASI) {
}

// buildQuarto builds a Quarto artifact.
func buildQuarto(artifact string, arguments Arguments, iasi IASI) {
}

// runPublish publishes the selected repositories.
func runPublish(arguments Arguments, directories []string) {
}

// runDeploy deploys the selected repositories.
func runDeploy(arguments Arguments, directories []string) {
}

// printHelp shows the command-line help.
func printHelp() {
	cli.Direct(`IASI Dev

Usage:
  iasi-dev <command> [-s] [-v] [--key value] [directory...]

Commands:
  help       Show help
  build      Build
  publish    Publish
  deploy     Deploy
`)
}
