// Command iasi-dev is the IASI development command-line entry point.
package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

type Arguments struct {
	Silent  bool
	Verbose bool
	Params  map[string]string
}

func main() {
	if len(os.Args) == 1 {
		printHelp()
		return
	}

	command := os.Args[1]
	arguments, directoryArgs := parseArguments(os.Args[2:])
	directories := selectDirectories(directoryArgs)

	runCommand(command, arguments, directories)
}

func parseArguments(args []string) (Arguments, []string) {
	arguments := Arguments{Params: map[string]string{}}
	directories := []string{}

	for len(args) > 0 {
		argument := args[0]

		switch argument {
		case "-s":
			arguments.Silent = true
			args = args[1:]
		case "-v":
			arguments.Verbose = true
			args = args[1:]
		default:
			if strings.HasPrefix(argument, "--") {
				key := strings.TrimPrefix(argument, "--")
				value := ""

				if len(args) > 1 {
					value = args[1]
					args = args[2:]
				} else {
					args = args[1:]
				}

				arguments.Params[key] = value
				continue
			}

			directories = append(directories, argument)
			args = args[1:]
		}
	}

	return arguments, directories
}

func selectDirectories(candidates []string) []string {
	if len(candidates) == 0 {
		candidates = []string{"."}
	}

	directories := []string{}

	for _, root := range candidates {
		if _, err := os.Stat(root); err != nil {
			fmt.Fprintf(os.Stderr, "Aviso: se ignora %q: no existe.\n", root)
			continue
		}

		filepath.WalkDir(root, func(path string, entry os.DirEntry, err error) error {
			if err != nil {
				fmt.Fprintf(os.Stderr, "Aviso: se ignora %q: %v.\n", path, err)
				return nil
			}

			if entry.IsDir() {
				directories = append(directories, path)
			}

			return nil
		})
	}

	return directories
}

func runCommand(command string, arguments Arguments, directories []string) {
	listDirectories(directories)
	return

	switch command {
	case "help":
		printHelp()
	case "build":
		runBuild(arguments, directories)
	case "publish":
		runPublish(arguments, directories)
	case "deploy":
		runDeploy(arguments, directories)
	default:
		fmt.Fprintf(os.Stderr, "Unknown command %q\n", command)
		os.Exit(2)
	}
}

func listDirectories(directories []string) {
	for _, directory := range directories {
		fmt.Println(directory)
	}
}

func runBuild(arguments Arguments, directories []string) {
}

func runPublish(arguments Arguments, directories []string) {
}

func runDeploy(arguments Arguments, directories []string) {
}

func printHelp() {
	fmt.Print(`IASI Dev

Usage:
  iasi-dev <command> [-s] [-v] [--key value] [directory...]

Commands:
  help       Show help
  build      Build
  publish    Publish
  deploy     Deploy
`)
}
